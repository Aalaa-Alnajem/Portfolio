// Section [Contact]

let maxLength = 100;
$('textarea').keyup(function (){
    let length = $(this).val().length;
    let counter = maxLength - length;
    if(counter <= 0){
        $('#char').text('your available character finished');
    }else{
        $('#char').text(counter)
    }
    
});