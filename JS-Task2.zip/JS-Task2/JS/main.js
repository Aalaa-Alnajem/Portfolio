var quote = document.getElementById('quote');
var quoteWriter = document.getElementById('quoteWriter');

var quotes = []

var quote1 = {
    quote : '“So many books, so little time.”',
    quoteWriter : ' Frank Zappa',
}
var quote2 = {
    quote : '“Two things are infinite: the universe and human stupidity; and I am not sure about the universe.”',
    quoteWriter : '- Albert Einstein',
}
var quote3 = {
    quote : '“A room without books is like a body without a soul.”',
    quoteWriter : '- Marcus Tullius Cicero',
}
var quote4 = {
    quote : '“Be who you are and say what you feel, because those who mind do not matter, and those who matter do not mind.”',
    quoteWriter : '- Bernard M. Baruch',
}
var quote5 = {
    quote : '“You know you are in love when you can not fall asleep because reality is finally better than your dreams.”',
    quoteWriter : '- Dr. Seuss',
}
var quote6 = {
    quote : '“Be the change that you wish to see in the world.”',
    quoteWriter : '- Mahatma Gandhi',
}
var quote7 = {
    quote : '“If you want to know what a man is like, take a good look at how he treats his inferiors, not his equals.”',
    quoteWriter : '- J.K. Rowling',
}
quotes.push (quote1, quote2, quote3, quote4, quote5, quote6, quote7);

var lastRandomQuote;

function chickGenerator(){
    var randomQuote = Math.floor(Math.random() * quotes.length);
    if (randomQuote === lastRandomQuote){
        if (randomQuote > 0){
            randomQuote = randomQuote - 1;
        }else{
            randomQuote = randomQuote + 1;
        }
    }
    changeQuote(randomQuote);
}
function changeQuote(randomQuote){
    quote.innerHTML = quotes[randomQuote].quote;
    quoteWriter.innerHTML = quotes[randomQuote].quoteWriter;
    
    lastRandomQuote = randomQuote;
}

// If you want to add new Quote :)

var addQuote = document.getElementById('addQuote');
var addName = document.getElementById('addName');

function addNewQuote(){
    var newQuote = {
        quote: addQuote.value,
        quoteWriter : addName.value,
    }
    quotes.push(newQuote);
    addQuote.value = '';
    addName.value = '';
}


