var typed = new Typed('#element',{
    strings: ['Designer','Developer'],
    typeSpeed: 100,
    backSpeed: 50,
    loop: true,
    loopCount: Infinity,
});
